package comp110;

import comp110.toys.Die;

/*
 * Author: <YOUR NAME>
 *
 * ONYEN: <YOUR ONYEN>
 *
 * UNC Honor Pledge: I certify that no unauthorized assistance has been 
 * received or given in the completion of this work. I collaborated with
 * no one other than official COMP110 UTAs on this code.
 */
public class P3_DropStopAndRoll {

	public static void main(String[] args) {

		Console console = new Console("Drop, Stop, or Roll");
		console.speed(0.5);

		Die die = new Die();

		console.print("Welcome to Drop, Stop, or Roll");

		// Do not change the code above. Begin your work after this comment.

		int toWin = console.promptInt("What are you playing to?");
		int roundNumber = 1;
		boolean rolling = true;
		boolean rolling1 = true;
		int score1 = 0;
		int score2 = 0;
		int totalScore1 = 0;
		int totalScore2 = 0;

		console.print("Round " + roundNumber);
		if (score1 == score2) {
			console.print("The game is tied " + score1 + " to " + score2);
		}
		console.alert("Player 1: Press OK to begin your turn.");

		while (rolling) {
			die.roll();
			int value = die.getValue();
			score1 = score1 + value;
			console.print("Player 1: You rolled a " + value);

			if (value == 1) {
				console.print("Player 1: You DROPPED this turn's points!");
				score1 = 0;
				console.print("Player 1: Total Score is " + totalScore1);
				rolling = false;
				console.alert("Player 2: Press OK to begin your turn");
				score2 = 0;
				rolling1 = true;

			} else {
				console.print("Player 1: Your turn score is " + score1);
				String choice = console.promptString("Player 1: Roll or Stop?");

				if (choice.equals("stop")) {
					totalScore1 = totalScore1 + score1;
					console.print("Player 1: Total Score is " + totalScore1);
					rolling = false;
					rolling1 = true;
					console.alert("Player 2: Press OK to begin your turn.");
					score2 = 0;
				} else {
					rolling1 = false;
				}
			}

			while (rolling1) {
				die.roll();
				int value2 = die.getValue();
				console.print("Player 2: You rolled a " + value2);

				if (value2 == 1) {
					console.print("Player 2: You DROPPED this turn's points!");
					value2 = 0;
					score2 = 0;
					score2 = score2 + value2;
					console.print("Player 2: Total score is " + totalScore2);
					rolling1 = false;
					rolling = true;
					if (totalScore1 >= toWin) {
						console.print("Player 1 wins " + totalScore1 + " to " + totalScore2);
						rolling = false;
						rolling1 = false;
					} else {
						roundNumber = roundNumber + 1;
						console.print("Round " + roundNumber);
						console.alert("Player 1: Press OK to begin your turn.");
						score1 = 0;
					}
				} else {
					score2 = score2 + value2;
					console.print("Player 2: Your turn score is " + score2);
					String choice1 = console.promptString("Player 2: Roll or Stop?");

					if (choice1.equals("stop")) {
						totalScore2 = totalScore2 + score2;
						console.print("Player 2: Total score is " + totalScore2);
						rolling1 = false;

						if (totalScore1 == totalScore2) {
							rolling = true;
							rolling1 = false;
							roundNumber = roundNumber + 1;
							console.print("Round " + roundNumber);
							console.print("The game is tied " + totalScore1 + " to " + totalScore2);
							console.alert("Player 1: Press OK to begin your turn.");
							score1 = 0;
						} else if ((totalScore1 > totalScore2) && (totalScore1 >= toWin)) {
							console.print("Player 1 wins " + totalScore1 + " to " + totalScore2);
						} else if ((totalScore2 > score1) && (totalScore2 >= toWin)) {
							console.print("Player 2 wins " + totalScore2 + " to " + totalScore1);
						} else if (totalScore1 > totalScore2) {
							rolling = true;
							rolling1 = false;
							roundNumber = roundNumber + 1;
							console.print("Round " + roundNumber);
							console.print("Player 1 leads " + totalScore1 + " to " + totalScore2);
							console.alert("Player 1: Press OK to begin your turn.");
							score1 = 0;
						} else if (totalScore2 > totalScore1) {
							rolling = true;
							rolling1 = false;
							roundNumber = roundNumber + 1;
							console.print("Round " + roundNumber);
							console.print("Player 2 leads " + totalScore2 + " to " + totalScore1);
							console.alert("Player 1: Press OK to begin your turn.");
							score1 = 0;
						} else {
							rolling = true;
							roundNumber = roundNumber + 1;
							console.print("Round " + roundNumber);
							console.alert("Player 1: Press OK to begin your turn.");
							score1 = 0;
						}
					} else {
						rolling = false;

					}
				}
			}

		}

	}

}