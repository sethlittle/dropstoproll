package comp110;

import comp110.toys.Die;

/*
 * Author: <YOUR NAME>
 *
 * ONYEN: <YOUR ONYEN>
 *
 * UNC Honor Pledge: I certify that no unauthorized assistance has been 
 * received or given in the completion of this work. I collaborated with
 * no one other than official COMP110 UTAs on this code.
 */
public class P2_OnePlayer {

	public static void main(String[] args) {

		Console console = new Console("One Player Drop, StopNLock, or Roll");
		console.speed(0.5);

		Die die = new Die();

		console.print("Welcome to One Player Drop, Stop, or Roll");

		// Do not change the code above. Begin your work after this comment.

		int toWin = console.promptInt("What are you playing to?");
		int roundNumber = 1;
		boolean rolling = true;
		int score = 0;

		console.print("Round " + roundNumber);
		console.alert("Press OK to begin your turn.");

		while (rolling) {

			die.roll();
			int value = die.getValue();
			console.print("You rolled a " + value);

			if (value == 1) {
				console.print("You DROPPED this turn's points!");
				score = 0;
				value = 0;
				roundNumber = roundNumber + 1;
				console.print("Total score is " + score);
				console.print("Round " + roundNumber);
				console.alert("Press OK to begin your turn.");

			} else {
				score = score + value;
				console.print("Your turn score is " + score);
				String choice = console.promptString("Roll or Stop?");

				if (choice.equals("stop")) {

					if (score >= toWin) {
						console.print("Total score is " + score);
						console.print("You won in " + roundNumber + " rounds with " + score + " points!");
						rolling = false;

					} else {
						roundNumber = roundNumber + 1;
						console.print("Total score is " + score);
						console.print("Round " + roundNumber);
						console.alert("Press OK to begin your turn.");

					}

				}
			}
		}
	}

}