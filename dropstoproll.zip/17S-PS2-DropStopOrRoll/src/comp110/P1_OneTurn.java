package comp110;

import comp110.toys.Die;

/*
 * Author: Seth Little
 *
 * ONYEN: sethl
 *
 * UNC Honor Pledge: I certify that no unauthorized assistance has been 
 * received or given in the completion of this work. I collaborated with
 * no one other than official COMP110 UTAs on this code.
 */
public class P1_OneTurn {

	public static void main(String[] args) {

		Console console = new Console("One Turn Drop, Stop, or Roll");
		console.speed(0.5);

		Die die = new Die();

		console.print("Welcome to One Turn Drop, Stop, and Roll");
		console.alert("Press OK to begin.");

		// Do not change the code above. Begin your work after this comment.

		boolean rolling = true;
		int score = 0;
		while (rolling) {
			die.roll();
			int value = die.getValue();
			console.print("You rolled a " + value);

			if (value == 1) {
				console.print("You DROPPED your points!");
				console.print("Your turn score is 0");
				rolling = false;

			} else {
				score = score + value;
				console.print("Your turn score is " + score);
				String choice = console.promptString("Roll or Stop?");
				if (choice.equals("stop")) {
					console.print("Your turn score is " + score);
					rolling = false;

				}
			}
		}

		console.print("Game Over");

	}

}